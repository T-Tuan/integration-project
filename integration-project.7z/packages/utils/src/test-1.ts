
export const test = (params: any) => {
  console.log(params);
  return true
}